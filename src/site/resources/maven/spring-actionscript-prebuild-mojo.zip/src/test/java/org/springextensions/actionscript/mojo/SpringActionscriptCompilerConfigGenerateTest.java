package org.springextensions.actionscript.mojo;

import org.apache.maven.plugin.testing.AbstractMojoTestCase;
import org.springextensions.actionscript.mojo.SpringActionscriptCompilerConfigGenerateMojo;

import java.io.File;

public class SpringActionscriptCompilerConfigGenerateTest extends AbstractMojoTestCase {

    /**
     * @throws Exception
     */
    public void testMojoGoal() throws Exception
    {
        String baseDir = getBasedir();
        File testPom = new File(baseDir,
          "src/test/resources/testconfig/basic-spring-as-config.xml" );

        SpringActionscriptCompilerConfigGenerateMojo mojo =
                (SpringActionscriptCompilerConfigGenerateMojo) lookupMojo ( "generate-compiler-config", testPom );

        assertNotNull( mojo );
    }
}
