package org.springextensions.actionscript.mojo;

/*
 * Copyright 2001-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;

/**
 * Goal which generates a flex compiler config file from context files.
 *
 * @goal generate-compiler-config
 * @phase generate-code
 */
public class SpringActionscriptCompilerConfigGenerateMojo
        extends AbstractMojo {
    /**
     * Location of the output directory.
     *
     * @parameter 
     * @required
     */
    private File outputDirectory;

    /**
     * Name of the config file to generate. This file will need to be included in the
     * flex compiler config
     *
     * @parameter expression="${springactionscript.compilerconfig.name}"
     * default-value="spring-actionscript-includes.config"
     */
    private String generatedConfigFileName;

    /**
     * Base directory of the project.
     *
     * @parameter expression="${basedir}"
     */
    private File baseDirectory;

    /**
     * A set of files to use to generate the compiler config.
     *
     * The current implementation will work properly for one context file, and will
     * generate an output if there are multiple files - but the output will have duplicate
     * entries in it.
     *
     * Usage:
     *  <pre>
     * &lt;springActionscriptContextFiles&gt;
     *   &lt;file&gt;${baseDir}/src/main/flex/applicationContext.xml&lt;/file&gt;
     * &lt;/springActionscriptContextFiles&gt;
     * </pre>
     *
     *
     * @parameter
     * @required
     */
    private File[] springActionscriptContextFiles;


    public void execute()
            throws MojoExecutionException {

        javax.xml.transform.TransformerFactory tFactory =
                    javax.xml.transform.TransformerFactory.newInstance();

        // 2a. Get the stylesheet from the XML source.
        String media = null , title = null, charset = null;
        javax.xml.transform.Source stylesheet;
        Transformer transformer;

        try {
           InputStream style = SpringActionscriptCompilerConfigGenerateMojo.class.getResourceAsStream("/org/springextensions/actionscript/mojo/spring-as3-config.xsl");
           transformer = tFactory.newTransformer( new StreamSource( style ) );
        }
        catch (TransformerConfigurationException e) {
            throw new MojoExecutionException("Unable to create transformer", e);
        }
        StreamResult result = new StreamResult(new ByteArrayOutputStream());
        if (springActionscriptContextFiles == null) {            
            getLog().error("No context files were found: Please make sure that the 'springActionscriptContextFiles' is set properly");
            throw new MojoExecutionException("No context file found to transform");
        }
        for (File contextFile :springActionscriptContextFiles) {
            try {
                transformer.transform
                    (new StreamSource(contextFile), result);
            } catch (TransformerException e) {
                throw new MojoExecutionException("Exception while trying to transform file: "
                                                    + contextFile.getAbsolutePath(), e);
            }

        }

        File outputFile = new File(outputDirectory, generatedConfigFileName);

        try {
            FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
            InputStream headerInputStream = SpringActionscriptCompilerConfigGenerateMojo.class.getResourceAsStream("/org/springextensions/actionscript/mojo/output-header.txt");
            byte[] header = new byte[headerInputStream.available()];
            headerInputStream.read(header);
            headerInputStream.close();
            fileOutputStream.write(header);
                        
            byte[] xslOutput = ((ByteArrayOutputStream)result.getOutputStream()).toByteArray();
            fileOutputStream.write(xslOutput);


            InputStream footerInputStream = SpringActionscriptCompilerConfigGenerateMojo.class.getResourceAsStream("/org/springextensions/actionscript/mojo/output-footer.txt");
            byte[] footer = new byte[footerInputStream.available()];
            footerInputStream.read(footer);
            footerInputStream.close();
            fileOutputStream.write(footer);

            fileOutputStream.close();
        } catch (IOException e) {
            throw new MojoExecutionException("Unable to write to output file", e);
        }
    }
 }
